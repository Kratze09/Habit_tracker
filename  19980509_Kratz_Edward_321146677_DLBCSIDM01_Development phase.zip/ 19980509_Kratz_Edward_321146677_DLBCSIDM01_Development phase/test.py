from Habit_Tracker import list_of_all_habits, habits_with_same_period,longest_streak_all_habits,longest_streak_given_habit,read_from_json
import pytest

def test_list_of_all_habits():
    data=[{'habit': 'Brushing teeth', 'period': 'daily', 'period track': {'1': {'checked': 1, 'time': '4/05/2022 07:38:30.281867'}, '2': {'checked': 1, 'time': '5/05/2022 07:39:06.311801'}, '3': {'checked': 1, 'time': '6/05/2022 07:39:28.334097'}, '4': {'checked': 1, 'time': '7/05/2022 07:39:48.346491'}, '5': {'checked': 1, 'time': '8/05/2022 07:40:10.355989'}, '6': {'checked': 0, 'time': 0}, '7': {'checked': 0, 'time': 0}, '8': {'checked': 1, 'time': '11/05/2022 07:41:22.402567'}, '9': {'checked': 
            1, 'time': '12/05/2022 07:41:56.427212'}, '10': {'checked': 0, 'time': 0}, '11': {'checked': 1, 'time': '14/05/2022 07:42:29.452373'}, '12': {'checked': 0, 'time': 0}, '13': {'checked': 0, 'time': 0}, '14': {'checked': 0, 'time': 0}, '15': {'checked': 0, 'time': 0}, '16': {'checked': 0, 'time': 0}, '17': {'checked': 0, 'time': 0}, '18': {'checked': 0, 'time': 0}, '19': {'checked': 0, 'time': 0}, '20': {'checked': 0, 'time': 0}, '21': {'checked': 0, 'time': 0}, '22': {'checked': 0, 'time': 0}, '23': {'checked': 0, 'time': 0}, '24': {'checked': 0, 'time': 0}, '25': {'checked': 0, 'time': 0}, '26': {'checked': 0, 'time': 0}}, 'started date': '2/05/2022 07:38:24.279949'}, {'habit': 'Reading a book', 'period': 'weekly', 'period track': {'1': {'checked': 1, 'time': '6/05/2022 07:39:02.300451'}, '2': {'checked': 1, 'time': '12/05/2022 07:41:16.386524'}, '3': {'checked': 0, 'time': 0}}, 'started date': '2/05/2022 07:38:24.279949'}, {'habit': 'Playing football', 'period': 'weekly', 'period track': {'1': {'checked': 1, 'time': '4/05/2022 07:39:36.339041'}, '2': {'checked': 0, 'time': 0}, '3': {'checked': 0, 'time': 0}, '4': {'checked': 1, 'time': 
            '28/05/2022 13:49:14.252548'}}, 'started date': '2/05/2022 07:38:24.279949'}, {'habit': 'Playing a video game', 'period': 'daily', 'period track': {'1': {'checked': 
            0, 'time': 0}, '2': {'checked': 1, 'time': '3/05/2022 07:38:52.295076'}, '3': {'checked': 0, 'time': 0}, '4': {'checked': 1, 'time': '5/05/2022 07:39:53.346682'}, '5': {'checked': 0, 'time': 0}, '6': {'checked': 1, 'time': '7/05/2022 07:40:26.366887'}, '7': {'checked': 0, 'time': 0}, '8': {'checked': 0, 'time': 0}, '9': {'checked': 0, 'time': 0}, '10': {'checked': 1, 'time': '11/05/2022 07:42:06.427982'}, '11': {'checked': 1, 'time': '12/05/2022 07:42:41.463668'}, '12': {'checked': 0, 'time': 0}, '13': {'checked': 0, 'time': 0}, '14': {'checked': 0, 'time': 0}, '15': {'checked': 0, 'time': 0}, '16': {'checked': 0, 'time': 0}, '17': {'checked': 0, 'time': 0}, '18': {'checked': 0, 'time': 0}, '19': {'checked': 0, 'time': 0}, '20': {'checked': 0, 'time': 0}, '21': {'checked': 0, 'time': 0}, '22': {'checked': 0, 'time': 0}, '23': {'checked': 0, 'time': 0}, '24': {'checked': 0, 'time': 0}, '25': {'checked': 0, 'time': 0}, '26': {'checked': 0, 'time': 0}}, 'started date': '2/05/2022 07:38:24.279949'}, {'habit': 'Doing exercise', 'period': 'weekly', 'period track': {'1': {'checked': 1, 'time': '11/05/2022 07:39:20.323496'}, '2': {'checked': 1, 
            'time': '16/05/2022 07:41:50.417317'}, '3': {'checked': 1, 'time': '24/05/2022 07:42:20.439198'}}, 'started date': '9/05/2022 07:38:24.279949'}, {'habit': 'Washing Cloths', 'period': 'daily', 'period track': {}, 'started date': '28/05/2022 14:10:34.870401'}]
        
    assert list_of_all_habits(data)==['Brushing teeth', 'Reading a book', 'Playing football', 'Playing a video game', 'Doing exercise', 'Washing Cloths']

def test_habits_with_same_period():
    data=[{'habit': 'Brushing teeth', 'period': 'daily', 'period track': {'1': {'checked': 1, 'time': '4/05/2022 07:38:30.281867'}, '2': {'checked': 1, 'time': '5/05/2022 07:39:06.311801'}, '3': {'checked': 1, 'time': '6/05/2022 07:39:28.334097'}, '4': {'checked': 1, 'time': '7/05/2022 07:39:48.346491'}, '5': {'checked': 1, 'time': '8/05/2022 07:40:10.355989'}, '6': {'checked': 0, 'time': 0}, '7': {'checked': 0, 'time': 0}, '8': {'checked': 1, 'time': '11/05/2022 07:41:22.402567'}, '9': {'checked': 
            1, 'time': '12/05/2022 07:41:56.427212'}, '10': {'checked': 0, 'time': 0}, '11': {'checked': 1, 'time': '14/05/2022 07:42:29.452373'}, '12': {'checked': 0, 'time': 0}, '13': {'checked': 0, 'time': 0}, '14': {'checked': 0, 'time': 0}, '15': {'checked': 0, 'time': 0}, '16': {'checked': 0, 'time': 0}, '17': {'checked': 0, 'time': 0}, '18': {'checked': 0, 'time': 0}, '19': {'checked': 0, 'time': 0}, '20': {'checked': 0, 'time': 0}, '21': {'checked': 0, 'time': 0}, '22': {'checked': 0, 'time': 0}, '23': {'checked': 0, 'time': 0}, '24': {'checked': 0, 'time': 0}, '25': {'checked': 0, 'time': 0}, '26': {'checked': 0, 'time': 0}}, 'started date': '2/05/2022 07:38:24.279949'}, {'habit': 'Reading a book', 'period': 'weekly', 'period track': {'1': {'checked': 1, 'time': '6/05/2022 07:39:02.300451'}, '2': {'checked': 1, 'time': '12/05/2022 07:41:16.386524'}, '3': {'checked': 0, 'time': 0}}, 'started date': '2/05/2022 07:38:24.279949'}, {'habit': 'Playing football', 'period': 'weekly', 'period track': {'1': {'checked': 1, 'time': '4/05/2022 07:39:36.339041'}, '2': {'checked': 0, 'time': 0}, '3': {'checked': 0, 'time': 0}, '4': {'checked': 1, 'time': 
            '28/05/2022 13:49:14.252548'}}, 'started date': '2/05/2022 07:38:24.279949'}, {'habit': 'Playing a video game', 'period': 'daily', 'period track': {'1': {'checked': 
            0, 'time': 0}, '2': {'checked': 1, 'time': '3/05/2022 07:38:52.295076'}, '3': {'checked': 0, 'time': 0}, '4': {'checked': 1, 'time': '5/05/2022 07:39:53.346682'}, '5': {'checked': 0, 'time': 0}, '6': {'checked': 1, 'time': '7/05/2022 07:40:26.366887'}, '7': {'checked': 0, 'time': 0}, '8': {'checked': 0, 'time': 0}, '9': {'checked': 0, 'time': 0}, '10': {'checked': 1, 'time': '11/05/2022 07:42:06.427982'}, '11': {'checked': 1, 'time': '12/05/2022 07:42:41.463668'}, '12': {'checked': 0, 'time': 0}, '13': {'checked': 0, 'time': 0}, '14': {'checked': 0, 'time': 0}, '15': {'checked': 0, 'time': 0}, '16': {'checked': 0, 'time': 0}, '17': {'checked': 0, 'time': 0}, '18': {'checked': 0, 'time': 0}, '19': {'checked': 0, 'time': 0}, '20': {'checked': 0, 'time': 0}, '21': {'checked': 0, 'time': 0}, '22': {'checked': 0, 'time': 0}, '23': {'checked': 0, 'time': 0}, '24': {'checked': 0, 'time': 0}, '25': {'checked': 0, 'time': 0}, '26': {'checked': 0, 'time': 0}}, 'started date': '2/05/2022 07:38:24.279949'}, {'habit': 'Doing exercise', 'period': 'weekly', 'period track': {'1': {'checked': 1, 'time': '11/05/2022 07:39:20.323496'}, '2': {'checked': 1, 
            'time': '16/05/2022 07:41:50.417317'}, '3': {'checked': 1, 'time': '24/05/2022 07:42:20.439198'}}, 'started date': '9/05/2022 07:38:24.279949'}, {'habit': 'Washing Cloths', 'period': 'daily', 'period track': {}, 'started date': '28/05/2022 14:10:34.870401'}]
        
    assert habits_with_same_period(data)==[['Brushing teeth', 'Playing a video game', 'Washing Cloths'], ['Reading a book', 'Playing football', 'Doing exercise']]

def test_longest_streak_all_habits():
    habits=read_from_json("habit data test.json")

    assert longest_streak_all_habits(habits)==[(5, 'daily'), (3, 'weekly')]

def test_longest_streak_given_habit():
    habits=read_from_json("habit data test.json")

    assert longest_streak_given_habit(habits[0])==(5, 'daily')

def test_longest_streak_given_habit():
    habits=read_from_json("habit data test.json")

    assert longest_streak_given_habit(habits[2])==(1, 'weekly')

def test_longest_streak_given_habit():
    habits=read_from_json("habit data test.json")

    assert longest_streak_given_habit(habits[4])==(3, 'weekly')


