# File organization

The following files should be in the same folder in order to run the program.
Habit_Tracker.py
test.py
habit data.json
habit data test.json

# Python version

Python 3.9.10 is used here.

# Library installation

pip install pytest

# Running the Habit Tracker program

1. Run the Habit_Tracker.py file
2. The main menu of the program will be displayed and user can select the required option
3. In the 'Create habit' option, user needs to enter the task of the habit and the periodicity
4. To quit the program, use 'Exit' option in the main menu

# Data representation

A single row in the JSON file represents the data about a single habit
