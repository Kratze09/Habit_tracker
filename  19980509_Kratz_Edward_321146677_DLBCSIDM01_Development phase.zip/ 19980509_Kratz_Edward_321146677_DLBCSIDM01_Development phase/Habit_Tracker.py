# import required libraries to the program
import time
import json
from datetime import date,datetime
import math

class Habit:
    '''
    This class creates the habit objects according to the user's specification.
    '''

    def __init__(self,spec,period):
        '''
        Define all the instance variables. Two parameters are taken from the user, when it is creating.

        spec - task specification of the habit
        period - periodicity of the habit (daily or weekly)
        '''
        self.spec=spec
        self.period=period
        self.date_format_str = '%d/%m/%Y %H:%M:%S.%f'
        self.initial_time=datetime.now().strftime(self.date_format_str)
        self.period_track={}
        self.period_count=len(list(self.period_track.keys()))

    def check_off(self):
        '''
        This method is used to check-off the habit. When user calls this method, it modify the track data dictionary.
        No external parameters are taken.
        '''
        start = datetime.strptime(self.initial_time, self.date_format_str)
        end_time=datetime.now().strftime(self.date_format_str)
        end = datetime.strptime(end_time, self.date_format_str)
        time_diff = end - start
        time_diff_in_hours = time_diff.total_seconds()/3600
        
        if self.period=='daily':
            while True:
                self.period_count+=1
                if time_diff_in_hours<=24*self.period_count:
                    self.period_track[self.period_count]={'checked':1,'time':end_time}
                    break
                else:
                    self.period_track[self.period_count]={'checked':0,'time':0}
        
        elif self.period=='weekly':
            while True:
                self.period_count+=1
                if time_diff_in_hours<=168*self.period_count:
                    self.period_track[self.period_count]={'checked':1,'time':end_time}
                    break
                else:
                    self.period_track[self.period_count]={'checked':0,'time':0}

    def habit_data(self):
        '''
        This method returns the important data about the habit as a dictionary.
        No external parameters are taken.
        '''
        data_dict ={
            "habit" : self.spec,
            "period" : self.period,
            "period track" : self.period_track,
            "started date" : self.initial_time
        }
  
        return data_dict

    def return_track_data(self):
        '''
        This method gives the habit tracking data for the last 4 weeks time period for both daily and weekly habits.
        No external parameters are taken.
        '''
        return_data={}
        if self.period=='weekly':
            if len(list(self.period_track.keys()))>4:
                for i in sort_str_as_int(list(self.period_track.keys()))[-4:]:
                    return_data[i]=self.period_track[i]
            else:
                return self.period_track
        else:
            if len(list(self.period_track.keys()))>28:
                for i in sort_str_as_int(list(self.period_track.keys()))[-28:]:
                    return_data[i]=self.period_track[i]
            else:
                return self.period_track

        return return_data

def create_habit():
    '''
    This function handles the habit object creation process.
    No external parameters are taken.
    Return the newly created habit object
    '''
    specs=input('Enter the habit specification: ')
    period=input('Enter the habit periodicity (daily/weekly): ')
    return Habit(specs, period)

def write_to_json(filename,data):
    '''
    This function is used to write data into a JSON file.
    Parameters:
    filename - the name of the JSON file
    data -  the data that need to be written into the file

    Nothing is returned
    '''
    with open(filename, "w") as outfile:
        for i in data:
            json.dump(i,outfile)
            outfile.write('\n')

def read_from_json(filename):
    '''
    This function reads data from a JSON file and return as a list
    Parameters:
    filename - the name of the JSON file

    Return the list of objects.
    '''

    lines = []
    for line in open(filename, 'r'):
        lines.append(json.loads(line))

    objects=[]
    for obj in lines:
        new_obj=Habit(obj['habit'], obj['period'])
        new_obj.initial_time=obj['started date']
        new_obj.period_track=obj['period track']
        new_obj.period_count=len(list(obj['period track']))
        objects.append(new_obj)

    return objects

def sort_str_as_int(lst):
    '''
    This function sorts a string integer list by considering as integer list. 
    Parameters:
    lst - list string integers

    Return a sorted list of string integers
    '''
    int_list=[int(i) for i in lst]
    sorted_int=sorted(int_list)
    str_list=[str(j) for j in sorted_int]
    return str_list

def mark_breakings(habit_list):
    '''
    This function updates the habit breakings for all the habits.
    Parameters:
    habit_list - the list of habit objects
    '''
    for k in habit_list:
        now_time=datetime.now().strftime(k.date_format_str)
        end = datetime.strptime(now_time, k.date_format_str)
        time_diff = end - datetime.strptime(k.initial_time,k.date_format_str)
        time_diff_in_hours = time_diff.total_seconds()/3600

        if k.period=='weekly' and len(list(k.period_track.keys()))<math.ceil(time_diff_in_hours/168):
            for i in range(len(list(k.period_track.keys()))+1,math.ceil(time_diff_in_hours/168)):
                k.period_track[i]={'checked':0,'time':0}

        elif k.period=='daily' and len(list(k.period_track.keys()))<math.ceil(time_diff_in_hours/24):
            for i in range(len(list(k.period_track.keys()))+1,math.ceil(time_diff_in_hours/24)):
                k.period_track[i]={'checked':0,'time':0}

    return habit_list

def list_of_all_habits(data):
    '''
    This function gives the list of all the habits that are currently tracking in the app.
    Parameters:
    data - a list of data dictionaries about the habits

    Return a list of habits.
    '''
    return_list=[]
    for d in data:
        return_list.append(d['habit'])
    return return_list

def habits_with_same_period(data):
    '''
    This function gives the list of all the habits that are currently tracking in the app according to the periodicity.
    Parameters:
    data - a list of data dictionaries about the habits

    Return a list of habit lists
    '''
    weekly_habits=[]
    daily_habits=[]
    for d in data:
        if d['period']=='weekly':
            weekly_habits.append(d['habit'])
        else:
            daily_habits.append(d['habit'])

    return [daily_habits,weekly_habits]

def longest_streak_given_habit(habit):
    '''
    This function calculates and returns the longest streak for the given habit.
    Parameters:
    habit - the habit object to use in calculation

    Return a tuple containing the longest streak and the periodicity of the habit
    '''
    longest_streak=0
    temp=0
    for i in sort_str_as_int(list(habit.period_track.keys())):
        if int(habit.period_track[i]['checked'])==1:
            temp+=1
        else:
            if temp>longest_streak:
                longest_streak=temp
                
            temp=0
    if temp>longest_streak:
        longest_streak=temp
    
    return (longest_streak,habit.period)

def longest_streak_all_habits(habits):
    '''
    This function calculates and returns the longest streak considering all the habits.
    Parameters:
    habits - the list of habit object to use in calculation

    Return a list containing the longest streak for daily tasks and weekly tasks
    '''
    longest_day=(0,0)
    longest_week=(0,0)
    for hb in habits:
        calc=longest_streak_given_habit(hb)
        if calc[0]>longest_day[0] and calc[1]=='daily':
            longest_day=calc
        elif calc[0]>longest_week[0] and calc[1]=='weekly':
            longest_week=calc

    return [longest_day,longest_week]


# time.sleep(6)
# habit_list[0].check_off()
# time.sleep(22)
# habit_list[3].check_off()
# time.sleep(10)
# habit_list[1].check_off()
# time.sleep(4)
# habit_list[0].check_off()
# time.sleep(14)
# habit_list[4].check_off()
# time.sleep(8)
# habit_list[0].check_off()
# time.sleep(8)
# habit_list[2].check_off()
# time.sleep(12)
# habit_list[0].check_off()
# time.sleep(5)
# habit_list[3].check_off()
# time.sleep(17)
# habit_list[0].check_off()
# time.sleep(16)
# habit_list[3].check_off()
# time.sleep(50)
# habit_list[1].check_off()
# time.sleep(6)
# habit_list[0].check_off()
# time.sleep(28)
# habit_list[4].check_off()
# time.sleep(6)
# habit_list[0].check_off()
# time.sleep(10)
# habit_list[3].check_off()
# time.sleep(14)
# habit_list[4].check_off()
# time.sleep(9)
# habit_list[0].check_off()
# time.sleep(12)
# habit_list[3].check_off()

# habit_list_new=mark_breakings(habit_list)
# write_data=[hb.habit_data() for hb in habit_list_new]
# write_to_json("habit data.json", write_data)

# loaded_habits=read_from_json("habit data.json")
# write_data=[hb.habit_data() for hb in loaded_habits]

# print(list_of_all_habits(write_data))
# print(habits_with_same_period(write_data))
# print(longest_streak_given_habit(loaded_habits[2]))
# print(longest_streak_all_habits(loaded_habits))
# print(loaded_habits[0].return_track_data())

def main():
    '''
    This function combines all previously defined functions and objects to manage the main process of the program.
    '''
    # habit_list=[Habit('Brushing teeth', 'daily'),Habit('Reading a book', 'weekly'),
    #                 Habit('Playing football', 'weekly'),Habit('Playing a video game', 'daily'),Habit('Doing exercise', 'weekly')]

    while True:
        print('----- Welcome to the Habit Tracker -----')
        print()
        print('*** Main Menu ***')
        print('1. Create a Habit\n2. Checked-off a Habit\n3. Delete a Habit\n4. Analyse Habits\n5. Exit\n')

        choise=input('Select you choice: ')
        if choise=='5':
            print('Successfully exited from the app.')
            break
        elif choise=='1':
            habits=read_from_json("habit data.json")
            read_data=[hb.habit_data() for hb in habits]

            new_habit=create_habit()
            habits.append(new_habit)
            habit_list_new=mark_breakings(habits)
            write_data=[hb.habit_data() for hb in habit_list_new]
            write_to_json("habit data.json", write_data)

        elif choise=='2':
            habits=read_from_json("habit data.json")
            read_data=[hb.habit_data() for hb in habits]
            all_habits=list_of_all_habits(read_data)
            print('List of all the current habits:-')
            for i in range(len(all_habits)):
                print('{}. {}'.format(i+1,all_habits[i]))

            selected=input('Select the habit you want to check-off: ')

            for h in habits:
                if h.spec==all_habits[int(selected)-1]:
                    h.check_off()
            
            habit_list_new=mark_breakings(habits)
            write_data=[hb.habit_data() for hb in habit_list_new]
            write_to_json("habit data.json", write_data)

        elif choise=='3':
            habits=read_from_json("habit data.json")
            read_data=[hb.habit_data() for hb in habits]
            all_habits=list_of_all_habits(read_data)
            print('List of all the current habits:-')
            for i in range(len(all_habits)):
                print('{}. {}'.format(i+1,all_habits[i]))

            selected=input('Select the habit you want to delete: ')

            for h in habits:
                if h.spec==all_habits[int(selected)-1]:
                    habits.remove(h)
                    break
            
            habit_list_new=mark_breakings(habits)
            write_data=[hb.habit_data() for hb in habit_list_new]
            write_to_json("habit data.json", write_data)

        elif choise=='4':
            habits=read_from_json("habit data.json")
            read_data=[hb.habit_data() for hb in habits]
            all_habits=list_of_all_habits(read_data)
            
            print('List of analytic functionalities:-')
            print('1. Get a list of all habits\n2. Get a list of all habits for given periodicity\n3. Check the longest streak of all habits\n4. Check the longest streak of selected habit')
            user_choise=input('Select the functionality you want: ')
            if user_choise=='1':
                print('List of all habits:-')
                for l in range(len(all_habits)):
                    print('{}. {}'.format(l+1,all_habits[l]))

            elif user_choise=='2':
                p=input('Enter the periodicity choise (weekly/daily): ')
                periodic_data=habits_with_same_period(read_data)
                
                if p=='daily':
                    print('List of all daily habits:-')
                    for l in range(len(periodic_data[0])):
                        print('{}. {}'.format(l+1,periodic_data[0][l]))

                elif p=='weekly':
                    print('List of all weekly habits:-')
                    for l in range(len(periodic_data[1])):
                        print('{}. {}'.format(l+1,periodic_data[1][l]))

                else:
                    print('You have entered an invalid choice.')

            elif user_choise=='3':
                ls=longest_streak_all_habits(habits)
                print('The longest streak for a daily task is',ls[0][0],'day streak.')
                print('The longest streak for a weekly task is',ls[1][0],'week streak.')

            elif user_choise=='4':
                print('List of all the current habits:-')
                for i in range(len(all_habits)):
                    print('{}. {}'.format(i+1,all_habits[i]))

                selected=input('Select the habit you want to get the longest steak: ')

                for h in habits:
                    if h.spec==all_habits[int(selected)-1]:
                        streak=longest_streak_given_habit(h)
                        print(streak)
                        if streak[1]=='daily':
                            print('The longest streak for the selected task is',streak[0],'day streak.')
                        else:
                            print('The longest streak for the selected task is',streak[0],'week streak.')
                        break
                 
            else:
                print('You have entered an invalid choise.')

        else:
            print('You have entered an invalid choise.')

if __name__=='__main__':
    main()
